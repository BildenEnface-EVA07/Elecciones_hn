-- Actualizada con una nueva tabla y un nuevo dato

CREATE DATABASE Elecciones_2025;
USE Elecciones_2025;

CREATE TABLE Personas (
idPersona INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
dni VARCHAR(13) UNIQUE NOT NULL,
nombreCompleto VARCHAR(100) NOT NULL,
haVotadoPresidente BOOLEAN,
haVotadoAlcalde BOOLEAN,
haVotadoDiputado BOOLEAN
);

CREATE TABLE Colaboradores (
idAdmin INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
idPersona INT UNIQUE NOT NULL,
correoElectronico VARCHAR(50) UNIQUE NOT NULL,
clave VARCHAR(255) NOT NULL, -- la contra va hasheada
rol ENUM('admin','colaborador') DEFAULT 'colaborador',
estaActivo BOOLEAN,
reset_token_hash VARCHAR (255) NULL DEFAULT NULL,
reset_token_expira DATETIME NULL DEFAULT NULL
);

CREATE TABLE Partidos (
idPartido INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
nombrePartido VARCHAR(50) NOT NULL,
siglas VARCHAR(5) NOT NULL,
logo BLOB
);

CREATE TABLE Candidatos (
idCandidato INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
idPartido INT NOT NULL,
nombreCandidato VARCHAR(100),
cargo ENUM('Diputado','Alcalde','Presidente'),
foto BLOB
);

CREATE TABLE CandidatosPresidencia (
idCandidato INT PRIMARY KEY NOT NULL
);

CREATE TABLE Departamentos (
idDepartamento INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
nombre VARCHAR(50)
);

CREATE TABLE Municipios (
idMunicipio INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
idDepartamento INT NOT NULL,
nombre VARCHAR(50)
);

CREATE TABLE CandidatosDiputados (
idCandidato INT PRIMARY KEY NOT NULL,
idDepartamento INT NOT NULL
);

CREATE TABLE CandidatosAlcaldes (
idCandidato INT PRIMARY KEY NOT NULL,
idMunicipio INT NOT NULL
);

CREATE TABLE Votaciones_Votos (
idVoto INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
idProcesoVotacion INT NOT NULL,
idPersona INT NOT NULL,
idCandidato INT NOT NULL,
fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE Proceso_Votacion (
idProcesoVotacion INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
sePuedeVotar BOOLEAN NOT NULL
);

ALTER TABLE Votaciones_Votos ADD FOREIGN KEY (idPersona) REFERENCES Personas (idPersona);
ALTER TABLE Votaciones_Votos ADD FOREIGN KEY (idCandidato) REFERENCES Candidatos (idCandidato);

ALTER TABLE Colaboradores ADD FOREIGN KEY (idPersona) REFERENCES Personas (idPersona);

ALTER TABLE Candidatos ADD FOREIGN KEY (idPartido) REFERENCES Partidos (idPartido);

ALTER TABLE CandidatosPresidencia ADD FOREIGN KEY (idCandidato) REFERENCES Candidatos (idCandidato);
ALTER TABLE CandidatosDiputados ADD FOREIGN KEY (idCandidato) REFERENCES Candidatos (idCandidato);
ALTER TABLE CandidatosAlcaldes ADD FOREIGN KEY (idCandidato) REFERENCES Candidatos (idCandidato);

ALTER TABLE CandidatosAlcaldes ADD FOREIGN KEY (idMunicipio) REFERENCES Municipios (idMunicipio);
ALTER TABLE CandidatosDiputados ADD FOREIGN KEY (idDepartamento) REFERENCES Departamentos (idDepartamento);

ALTER TABLE Municipios ADD FOREIGN KEY (idDepartamento) REFERENCES Departamentos (idDepartamento);

ALTER TABLE Votaciones_Votos ADD FOREIGN KEY (idProcesoVotacion) REFERENCES Proceso_Votacion (idProcesoVotacion);

INSERT INTO Proceso_Votacion (sePuedeVotar) VALUES (1); -- Inicializar por defecto un proceso de votacion