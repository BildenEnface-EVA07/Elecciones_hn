# Elecciones_hn
Proyecto de clase de Sistemas Operativos I, hecho por Heyden, Hector y Bilander
